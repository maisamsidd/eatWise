import 'package:flutter/material.dart';

class MyColors {
  static Color whiteColor = Colors.white;
  static Color BlackColor = Colors.black;
  static Color greyColor = const Color.fromARGB(255, 235, 227, 227);
}
